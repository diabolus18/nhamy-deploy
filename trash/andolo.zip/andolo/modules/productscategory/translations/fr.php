<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productscategory}manfume>productscategory_4aae87211f77aada2c87907121576cfe'] = 'autres produits dans la même catégorie :';
