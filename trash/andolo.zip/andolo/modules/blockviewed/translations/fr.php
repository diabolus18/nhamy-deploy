<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockviewed}manfume>blockviewed_43560641f91e63dc83682bc598892fa1'] = 'Déjà vus';
$_MODULE['<{blockviewed}manfume>blockviewed_49fa2426b7903b3d4c89e2c1874d9346'] = 'En savoir plus sur';
