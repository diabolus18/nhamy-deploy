<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcart}andolo>blockcart_a85eba4c6c699122b2bb1387ea4813ad'] = 'Chariot';
$_MODULE['<{blockcart}andolo>blockcart_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Transport maritime';
$_MODULE['<{blockcart}andolo>blockcart_4b78ac8eb158840e9638a3aeb26c4a9d'] = 'Impôt';
$_MODULE['<{blockcart}andolo>blockcart_377e99e7404b414341a9621f7fb3f906'] = 'Commander';
