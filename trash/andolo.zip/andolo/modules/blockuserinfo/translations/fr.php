<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockuserinfo}andolo>blockuserinfo_bea8d9e6a0d57c4a264756b4f9822ed9'] = 'Mon compte';
$_MODULE['<{blockuserinfo}andolo>blockuserinfo_83218ac34c1834c26781fe4bde918ee4'] = 'Accueil';
$_MODULE['<{blockuserinfo}andolo>blockuserinfo_4394c8d8e63c470de62ced3ae85de5ae'] = 'Déconnexion';
$_MODULE['<{blockuserinfo}andolo>blockuserinfo_bffe9a3c9a7e00ba00a11749e022d911'] = 'identifiez-vous';
$_MODULE['<{blockuserinfo}andolo>blockuserinfo_dc1c2b8c25c07bd49078e2bedee6d512'] = 'Mon Panier:';
