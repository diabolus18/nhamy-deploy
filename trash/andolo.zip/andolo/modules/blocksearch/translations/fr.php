<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksearch}manfume>blocksearch-top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Rechercher';
$_MODULE['<{blocksearch}manfume>blocksearch-top_7081a7bab016441875f07beea4f3e5f4'] = 'Recherche de ';
