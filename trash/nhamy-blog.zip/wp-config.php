<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('WP_CACHE', true); //Added by WP-Cache Manager
define( 'WPCACHEHOME', '/home/justc739/public_html/nhamy.com.br/blog/wp-content/plugins/wp-super-cache/' ); //Added by WP-Cache Manager
define('DB_NAME', 'justc739_wrdp8');

/** MySQL database username */
define('DB_USER', 'justc739_wrdp8');

/** MySQL database password */
define('DB_PASSWORD', 'IOIOdCVfb81VDVMV');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '/v-/Jln^kq6jZKsT~9dZItl5*G|NsIXiyMtZ;cEOaiewKu^WH|4>5PEqEkJf7i^z^ol09/LI');
define('SECURE_AUTH_KEY',  '9B7d~MPo*VMuZx|>BF=io\`Z:UI1uq4Nks@Os!o<Flvzb!0jpJBm(a!qxIc$a');
define('LOGGED_IN_KEY',    '5M1T#FJ5F>9ZJ|r9KB!CUZLMQp/$OTyHb;-5U-=DZ17m:F~cDG*e?sV4#CXuQIWJ~ekgL9~yE/P:~4kE');
define('NONCE_KEY',        'vZ4jHd7Q:7Dwzs|DRO_I=?R9-VWOXpF08Tp8\`G|TuGfi5q|(W@Fdp6bAv>t*0TxO>lcgIF|Hp@<?');
define('AUTH_SALT',        'S;|J\`(!rq9unlmvVP:/VOM<@-1\`Pzo\`N?o9PwhjdTyrd<^)e_#s>/W3ZI');
define('SECURE_AUTH_SALT', 'o8V$$FycW8KD|Mld*M-|IWXT\`($QJ62YsecC/;XnI>_6PxiKcH9FVjVjSB|$$f?gRy1D');
define('LOGGED_IN_SALT',   'KE?Yb56CJE*ir-Sa84E-4ouLdHK)|b4v!yK;KX1lhtw2DWR-2!WQNbQCW4$a;sZ7yI;l1@2');
define('NONCE_SALT',       'FXs(rVJZU?8Afv~m6_Az3OR0t9Qq$oH!H)c6*8OoYW|fDmIl^Sref-vT)YmJE8:>*X2RT/5');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
