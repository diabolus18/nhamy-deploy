<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{csmegamenu}prestashop>csmegamenu_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_MODULE['<{csmegamenu}prestashop>csmegamenu_b55197a49e8c4cd8c314bc2aa39d6feb'] = 'En de stock';
