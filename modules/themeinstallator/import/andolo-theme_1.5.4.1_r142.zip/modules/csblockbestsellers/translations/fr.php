<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{csblockbestsellers}prestashop>csblockbestsellers-home_01f7ac959c1e6ebbb2e0ee706a7a5255'] = 'Meilleures Ventes';
$_MODULE['<{csblockbestsellers}prestashop>csblockbestsellers_01f7ac959c1e6ebbb2e0ee706a7a5255'] = 'Meilleures Ventes';
