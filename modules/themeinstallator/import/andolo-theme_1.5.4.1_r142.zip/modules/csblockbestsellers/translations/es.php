<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockbestsellers}prestashop>blockbestsellers-home_3cb29f0ccc5fd220a97df89dafe46290'] = 'Mejores ventas';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_95d17a0a1b5ea2de13a3565ed400ebbb'] = 'Añadir un bloque para mostrar las mejores ventas de la tienda';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = 'Mejores ventas';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_f7be84d6809317a6eb0ff3823a936800'] = 'No hay productos más vendidos en este momento';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers-home_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Más';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers-home_eae99cd6a931f3553123420b16383812'] = 'Los productos más vendidos';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_a8a670d89a6d2f3fa59942fc591011ef'] = 'Mostrar este bloque aunque no haya productos disponibles';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_eae99cd6a931f3553123420b16383812'] = 'Los productos más vendidos';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers-home_f7be84d6809317a6eb0ff3823a936800'] = 'No hay productos más vendidos en este momento';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_6232eaff79c9ccb6c1a66e5a75a212d5'] = 'Bloque de mejores ventas';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_c888438d14855d7d96a2724ee9c306bd'] = 'Actualización realizada con éxito';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers-home_4351cfebe4b61d8aa5efa1d020710005'] = 'Vista';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_530c88f8210e022b39128e3f0409bbcf'] = 'Mostrar este bloque siempre';
