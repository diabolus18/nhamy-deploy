<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontactinfos}andolo>blockcontactinfos_02d4482d332e1aef3437cd61c9bcc624'] = 'Contactez-nous';
