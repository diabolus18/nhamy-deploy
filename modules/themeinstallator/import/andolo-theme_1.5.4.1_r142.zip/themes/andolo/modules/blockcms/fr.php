<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcms}andolo>blockcms_d5552e0564007d93ff5937a9cb3bc491'] = 'Cervice à la clientèle';
$_MODULE['<{blockcms}andolo>blockcms_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Informations';
