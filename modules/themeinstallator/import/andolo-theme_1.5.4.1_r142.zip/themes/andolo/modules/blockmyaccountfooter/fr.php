<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmyaccountfooter}andolo>blockmyaccountfooter_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mon compte';
