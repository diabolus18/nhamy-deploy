﻿Presthemes Andolo Prestashop ThemeTheme
by PresThemes.com
Version Prestashop: 1.5.2.x, 1.5.3.x, 1.5.4.x

Userguide: http://presthemes.com/manual/andolo_1.5/
	
Or contact to support@presthemes.com 